# Cậu có thích tớ không ???


![image](https://github.com/user-attachments/assets/d8b7e789-cf98-47fd-af50-f4ecc5eac831)
